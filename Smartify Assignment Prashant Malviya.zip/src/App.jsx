import React from "react";
import AutoTopUpComponent from "./AutoTopUp/AutoTopUpComponent";

function App() {
  return (
    <>
      <AutoTopUpComponent />
    </>
  );
}

export default App;

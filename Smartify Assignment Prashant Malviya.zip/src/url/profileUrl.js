const profileUrl = 'https://github.com/Prashant-Malviya';

export default profileUrl;